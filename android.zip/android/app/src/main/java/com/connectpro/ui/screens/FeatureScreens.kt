package com.connectpro.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.connectpro.ui.theme.ConnectProSpacing

@Composable
fun TrustedContactsScreen() {
    FeaturePlaceholder(
        heading = "Your trusted network",

        description = "This section will help you organize the people you trust as part of your personal safety plan.",

        statusTitle = "Contact management is not connected yet",

        statusDescription = "Adding, editing, removing and syncing trusted contacts will be implemented in a later phase."
    )
}

@Composable
fun ActivityScreen() {
    FeaturePlaceholder(
        heading = "Your activity history",

        description = "This section is intended for reviewing relevant activity associated with ConnectPro.",

        statusTitle = "Activity tracking is not connected yet",

        statusDescription = "No activity records are being presented. Activity history will be implemented when the relevant workflows are available."
    )
}

@Composable
fun ProfileScreen() {
    FeaturePlaceholder(
        heading = "Your profile",

        description = "Your account information and preferences will be organized here.",

        statusTitle = "Profile settings are not connected yet",

        statusDescription = "Account details and profile settings will be implemented in a later phase."
    )
}

@Composable
private fun FeaturePlaceholder(
    heading: String,
    description: String,
    statusTitle: String,
    statusDescription: String
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(
                horizontal = ConnectProSpacing.ScreenHorizontal,
                vertical = ConnectProSpacing.Large
            ),

        verticalArrangement = Arrangement.spacedBy(
            ConnectProSpacing.Large
        )
    ) {

        // Screen introduction
        Column(
            verticalArrangement = Arrangement.spacedBy(
                ConnectProSpacing.Small
            )
        ) {
            Text(
                text = heading,

                style = MaterialTheme.typography.headlineMedium,

                color = MaterialTheme.colorScheme.onBackground
            )

            Text(
                text = description,

                style = MaterialTheme.typography.bodyLarge,

                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Honest feature placeholder
        Card(
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(
                    ConnectProSpacing.Large
                ),

                verticalArrangement = Arrangement.spacedBy(
                    ConnectProSpacing.Medium
                )
            ) {
                Text(
                    text = statusTitle,

                    style = MaterialTheme.typography.titleMedium,

                    color = MaterialTheme.colorScheme.onSurface
                )

                Text(
                    text = statusDescription,

                    style = MaterialTheme.typography.bodyMedium,

                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
