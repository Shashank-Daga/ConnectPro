package com.connectpro.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.connectpro.ui.theme.ConnectProSpacing

@Composable
fun HomeScreen(
    onOpenTrustedContacts: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(
                horizontal = ConnectProSpacing.ScreenHorizontal,
                vertical = ConnectProSpacing.Large
            ),

        verticalArrangement = Arrangement.spacedBy(
            ConnectProSpacing.Large
        )
    ) {

        // Main introduction
        Column(
            verticalArrangement = Arrangement.spacedBy(
                ConnectProSpacing.Small
            )
        ) {
            Text(
                text = "Your safety, connected.",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground
            )

            Text(
                text = "ConnectPro is your personal safety and emergency response platform.",

                style = MaterialTheme.typography.bodyLarge,

                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Trusted contacts entry point
        Card(
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(
                    ConnectProSpacing.Large
                ),

                verticalArrangement = Arrangement.spacedBy(
                    ConnectProSpacing.Medium
                )
            ) {
                Text(
                    text = "Build your trusted network",

                    style = MaterialTheme.typography.titleLarge,

                    color = MaterialTheme.colorScheme.onSurface
                )

                Text(
                    text = "Trusted contacts are an important part of a personal safety plan. Contact management will be connected in a later phase.",

                    style = MaterialTheme.typography.bodyMedium,

                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Button(
                    onClick = onOpenTrustedContacts,

                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(
                            min = ConnectProSpacing.MinimumTouchTarget
                        )
                ) {
                    Text("View Trusted Contacts")
                }
            }
        }

        // Transparent feature availability information
        Card(
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(
                    ConnectProSpacing.Large
                ),

                verticalArrangement = Arrangement.spacedBy(
                    ConnectProSpacing.Small
                )
            ) {
                Text(
                    text = "ConnectPro is being built in phases",

                    style = MaterialTheme.typography.titleMedium,

                    color = MaterialTheme.colorScheme.onSurface
                )

                Text(
                    text = "Contact management, activity tracking and account settings are not connected yet. These areas will become available as their workflows are implemented.",

                    style = MaterialTheme.typography.bodyMedium,

                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
